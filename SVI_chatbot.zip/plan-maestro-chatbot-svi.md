# PLAN MAESTRO DE IMPLEMENTACIÓN

**Chatbot inteligente para S.V.I. — Sistema de Vigilancia y Monitoreo Integral**

---

## Tabla de contenido

1. [Contexto del proyecto](#1-contexto-del-proyecto)
2. [Objetivo del chatbot](#2-objetivo-del-chatbot)
3. [Tecnologías](#3-tecnologías)
4. [Arquitectura del chatbot](#4-arquitectura-del-chatbot)
5. [Interfaz gráfica del chatbot](#5-interfaz-gráfica-del-chatbot)
6. [Avatar del chatbot](#6-avatar-del-chatbot)
7. [Tema visual](#7-tema-visual)
8. [Modo claro](#8-modo-claro)
9. [Modo oscuro](#9-modo-oscuro)
10. [Cambio claro / oscuro](#10-cambio-claro--oscuro)
11. [Ajuste del tamaño de letra](#11-ajuste-del-tamaño-de-letra)
12. [Diseño de la pantalla principal](#12-diseño-de-la-pantalla-principal)
13. [Mensaje de bienvenida](#13-mensaje-de-bienvenida)
14. [Chat conversacional](#14-chat-conversacional)
15. [Funciones operativas](#15-funciones-operativas)
16. [Reportes](#16-reportes)
17. [Exportación](#17-exportación)
18. [Análisis inteligente](#18-análisis-inteligente)
19. [Multilingüismo](#19-multilingüismo)
20. [Declaración de la Persona Transhumana](#20-declaración-de-la-persona-transhumana)
21. [Principio del día](#21-principio-del-día)
22. [Reflexión](#22-reflexión)
23. [Retos](#23-retos)
24. [Mi evolución](#24-mi-evolución)
25. [Modos del chat](#25-modos-del-chat)
26. [Base de conocimiento](#26-base-de-conocimiento)
27. [Base transhumana](#27-base-transhumana)
28. [RAG y contexto](#28-rag-y-contexto)
29. [Seguridad](#29-seguridad)
30. [Estructura de archivos](#30-estructura-de-archivos)
31. [Backend](#31-backend)
32. [Base de datos](#32-base-de-datos)
33. [Responsive](#33-responsive)
34. [Accesibilidad](#34-accesibilidad)
35. [Animaciones](#35-animaciones)
36. [Pruebas](#36-pruebas)
37. [Pruebas de seguridad](#37-pruebas-de-seguridad)
38. [Regla fundamental del chatbot](#38-regla-fundamental-del-chatbot)
39. [Experiencia final esperada](#39-experiencia-final-esperada)
40. [Orden de ejecución para Antigravity](#40-orden-de-ejecución-para-antigravity)
41. [Criterio de terminado](#41-criterio-de-terminado)
42. [Instrucción final para Antigravity](#-instrucción-final-para-antigravity)
43. [Recomendación importante antes de ejecutarlo](#-recomendación-importante-antes-de-ejecutarlo)

---

## 1. Contexto del proyecto

Se está desarrollando un **Sistema de Vigilancia y Monitoreo Integral (S.V.I.)**, cuya aplicación frontend está desarrollada en **Flutter** y cuyo backend está desarrollado en **Laravel**, utilizando **MySQL** como base de datos.

Actualmente existe una planificación para incorporar un chatbot utilizando **Gemini 2.5 Flash**, con Laravel como proxy para proteger la API Key.

El objetivo es implementar un asistente conversacional inteligente integrado dentro de la aplicación existente, sin crear una aplicación independiente y sin modificar innecesariamente módulos que ya funcionan.

La implementación debe ser **incremental, modular, segura y reversible**.

> **IMPORTANTE:** antes de modificar código, analizar la estructura actual de:
>
> - `vigilancia_app/`
> - `vigilancia-api/`
>
> y reutilizar los componentes existentes.

**NO** eliminar ni reemplazar funcionalidades existentes que no estén relacionadas con el chatbot.

---

## 2. Objetivo del chatbot

El chatbot debe convertirse en el **asistente inteligente oficial del S.V.I.**

Debe permitir:

- Consultar información sobre el sistema.
- Consultar cámaras y dispositivos.
- Consultar alertas.
- Consultar eventos.
- Analizar estadísticas.
- Realizar comparaciones y tendencias.
- Generar reportes.
- Explicar cómo utilizar la aplicación.
- Resolver dudas sobre los módulos.
- Respetar los permisos del usuario.
- Comunicarse en diferentes idiomas.
- Incorporar de forma interactiva la Declaración de la Persona Transhumana.
- Mostrar principios, reflexiones y retos.
- Llevar seguimiento de los retos y progreso.
- Mantener conversaciones contextuales.
- Proporcionar una interfaz moderna relacionada visualmente con un sistema de vigilancia.

---

## 3. Tecnologías

Mantener la arquitectura existente:

```text
Flutter
   ↓
Laravel API
   ↓
Gemini 2.5 Flash
   ↓
MySQL
```

Utilizar:

| Tecnología | Uso |
|---|---|
| Flutter | Interfaz |
| Dart | Lógica frontend |
| Laravel / PHP | Backend |
| MySQL | Datos |
| Gemini 2.5 Flash | Procesamiento conversacional |
| Sanctum | Autenticación |
| JSON | Bases de conocimiento |
| API REST | Comunicación |
| `.env` | Credenciales |

> ⚠️ La API Key de Gemini **NO** debe almacenarse en Flutter en producción. Debe permanecer en Laravel.

---

## 4. Arquitectura del chatbot

```text
                         USUARIO
                            │
                            ▼
                 ┌────────────────────┐
                 │   CHATBOT S.V.I.   │
                 │      Flutter       │
                 └─────────┬──────────┘
                           │
                           ▼
                 ┌────────────────────┐
                 │    Laravel API     │
                 │ ChatbotController  │
                 └─────────┬──────────┘
                           │
             ┌─────────────┼─────────────┐
             │             │             │
             ▼             ▼             ▼
        S.V.I. JSON    Transhumano    MySQL
        conocimiento   conocimiento    datos reales
             │             │             │
             └─────────────┼─────────────┘
                           ▼
                    Gemini 2.5 Flash
                           │
                           ▼
                    Respuesta final
                           │
                           ▼
                         Flutter
```

---

## 5. Interfaz gráfica del chatbot

La interfaz debe integrarse visualmente con la aplicación S.V.I.

No crear un diseño genérico tipo chatbot comercial. Debe parecer un **módulo nativo del sistema de vigilancia**.

### 5.1 Acceso al chatbot

Agregar un botón flotante:

```text
             ┌───────────────┐
             │       🤖      │
             │   S.V.I. AI   │
             └───────────────┘
```

Preferiblemente utilizar el avatar de la cámara humanoide como icono.

**El botón debe estar disponible en:**

- Dashboard.
- Cámaras/dispositivos.
- Alertas.
- Mapa.
- Reportes.

**No mostrarlo en:**

- Login.
- Registro.

El acceso requiere autenticación.

---

## 6. Avatar del chatbot

Crear un avatar propio para el asistente.

### Concepto

El avatar debe representar una **cámara de vigilancia humanoide inteligente**. No debe ser un robot humano genérico.

### Características visuales

- Cabeza basada en una cámara de seguridad.
- Lente central.
- Pequeños elementos tecnológicos.
- Forma humanoide.
- Apariencia futurista.
- Profesional.
- Amigable.
- Relacionada con vigilancia.
- Sin aspecto infantil.
- Sin parecer un personaje de videojuego.
- Diseño limpio y tecnológico.

### Concepto visual

```text
                 _________
                /         \
               /   ◉   ◉   \
              |      ●      |
              |   CAMERA    |
               \___________/
                    │
              ┌─────┴─────┐
              │   S.V.I.  │
              └─────┬─────┘
                 ┌──┴──┐
                 │     │
                /       \
               /         \
```

El elemento principal debe ser el **lente de cámara**.

### Estados y animaciones

| Estado | Comportamiento |
|---|---|
| Normal | Lente iluminado suavemente. |
| Pensando | Lente realizando una animación circular. |
| Escribiendo | Pequeña animación tecnológica. |
| Respondiendo | Lente iluminado. |
| Error | Cambiar temporalmente el indicador visual. |
| Escuchando | Animación alrededor del lente. |

---

## 7. Tema visual

El chatbot debe utilizar el sistema visual existente de S.V.I., reforzando una identidad visual basada en:

🔵 **Azul tecnológico**

El color principal debe estar relacionado con:

- Vigilancia.
- Tecnología.
- Seguridad.
- Información.
- Inteligencia artificial.

Evitar saturar toda la pantalla de azul. Utilizar azul principalmente en:

- Botones.
- Indicadores.
- Avatar.
- Bordes.
- Estados activos.
- Elementos seleccionados.

---

## 8. Modo claro

Debe existir un modo claro.

**Características:**

- Fondo claro.
- Tarjetas blancas o ligeramente grisáceas.
- Texto oscuro.
- Azul tecnológico para elementos activos.
- Avatar claramente visible.
- Alto contraste.
- Interfaz limpia.

**Ejemplo conceptual:**

```text
┌─────────────────────────────────┐
│ 🔵 S.V.I. Assistant             │
│                           ⚙️    │
├─────────────────────────────────┤
│                                 │
│       [AVATAR CÁMARA]           │
│                                 │
│  Hola, soy el asistente S.V.I.  │
│  ¿En qué puedo ayudarte?        │
│                                 │
│ [Cámaras] [Alertas] [Reportes]  │
│                                 │
├─────────────────────────────────┤
│ Escribe un mensaje...       ➤   │
└─────────────────────────────────┘
```

---

## 9. Modo oscuro

El modo oscuro debe ser especialmente importante porque el sistema es de vigilancia.

**Utilizar:**

- Fondo azul muy oscuro/negro.
- Paneles ligeramente diferenciados.
- Azul tecnológico para elementos activos.
- Texto claro.
- Avatar con iluminación azul.
- Contraste adecuado.

**Conceptualmente:**

```text
┌─────────────────────────────────┐
│ 🔵 S.V.I. Assistant             │
│                           ☼     │
├─────────────────────────────────┤
│                                 │
│         ◉                       │
│       CAMERA                    │
│       S.V.I.                    │
│                                 │
│  ¿Qué deseas consultar?         │
│                                 │
│ [📹 Cámaras] [🚨 Alertas]       │
│ [📊 Reportes] [🌱 Transhumano]  │
│                                 │
├─────────────────────────────────┤
│ Escribe un mensaje...       ➤   │
└─────────────────────────────────┘
```

---

## 10. Cambio claro / oscuro

Agregar una opción en la configuración del chatbot:

**Apariencia**

- ☀️ Claro
- 🌙 Oscuro
- ⚙️ Automático

**Automático:** debe utilizar la configuración global de la aplicación.

No crear un sistema de temas independiente si ya existe uno. Reutilizar, si existen:

- `app_colors.dart`
- `app_theme.dart`
- `theme_controller`

---

## 11. Ajuste del tamaño de letra

Agregar una opción de accesibilidad:

**Tamaño del texto**

- A — Pequeño
- A — Normal
- A — Grande
- A — Muy grande

También se puede implementar: `A−` `A` `A+`

**El tamaño debe afectar:**

- Mensajes del usuario.
- Respuestas del chatbot.
- Botones.
- Opciones.
- Títulos.
- Elementos de accesibilidad.

Debe evitarse que el texto grande rompa el diseño. Utilizar diseño responsive.

---

## 12. Diseño de la pantalla principal

### Encabezado

```text
┌─────────────────────────────────┐
│ ◉  S.V.I. Assistant       ⚙️    │
│    Asistente inteligente        │
└─────────────────────────────────┘
```

**Mostrar:**

- Avatar pequeño.
- Nombre.
- Estado.
- Configuración.

Por ejemplo: 🟢 Asistente disponible

---

## 13. Mensaje de bienvenida

Al iniciar:

> 👋 Hola, soy el asistente inteligente de S.V.I.
>
> Puedo ayudarte a consultar cámaras, alertas, eventos, estadísticas, reportes y también explorar la Declaración de la Persona Transhumana.

**Accesos rápidos:**

- 📹 Cámaras
- 🚨 Alertas
- 📊 Estadísticas
- 📄 Reportes
- 🌱 Persona Transhumana
- 🌎 Idioma

---

## 14. Chat conversacional

**Implementar:**

- Burbuja de usuario.
- Burbuja del asistente.
- Hora.
- Scroll automático.
- Indicador de escritura.
- Reintentar.
- Copiar respuesta.
- Limpiar conversación.

La estructura actual ya contempla `chat_bubble.dart`, `chat_input_bar.dart`, `typing_indicator.dart` y `chatbot_fab.dart`; reutilizar esa idea y ampliarla.

---

## 15. Funciones operativas

El chatbot debe soportar preguntas como:

| Categoría | Ejemplo |
|---|---|
| Cámaras | ¿Cuántas cámaras están activas? |
| Cámaras | ¿Cuál cámara está desconectada? |
| Alertas | ¿Cuántas alertas hubo hoy? |
| Alertas | ¿Hay alertas críticas? |
| Eventos | ¿Cuántos eventos ocurrieron ayer? |
| Estadísticas | ¿Cuál cámara tuvo más actividad? |
| Análisis | ¿A qué hora se presentan más eventos? |
| Reportes | Genera el reporte semanal. |

---

## 16. Reportes

Implementar un módulo: **📄 REPORTES**

- Reporte diario
- Reporte semanal
- Reporte mensual
- Reporte de cámaras
- Reporte de alertas
- Reporte de eventos
- Reporte personalizado

El usuario también podrá solicitar reportes mediante lenguaje natural.

**Ejemplo:**

> "Genera un reporte de las alertas críticas de esta semana."

El backend debe obtener los **datos reales**. El chatbot **no debe inventar estadísticas**.

---

## 17. Exportación

Permitir:

- **[Ver reporte]**
- **[📄 PDF]**
- **[📊 Excel]**

**El reporte debe incluir:**

- Título.
- Fecha.
- Periodo.
- Usuario.
- Resumen.
- Estadísticas.
- Tablas.
- Observaciones.
- Información relevante.

---

## 18. Análisis inteligente

El chatbot debe poder interpretar resultados.

**Ejemplo:**

> **Usuario:** ¿Cuál fue la cámara con más actividad?
>
> **Sistema:** La cámara 03 registró 147 eventos, siendo la cámara con mayor actividad durante el periodo consultado.

También: *"Compara esta semana con la anterior."*

Debe producir:

```text
Semana actual:   324 eventos
Semana anterior: 278 eventos

Variación: +16.5 %
```

> Los cálculos deben realizarse mediante **código/backend**. Gemini debe encargarse principalmente de interpretar la solicitud y presentar los resultados.

---

## 19. Multilingüismo

Implementar: **🌎 Idioma**

- Automático
- 🇨🇴 Español
- 🇺🇸 English
- 🇫🇷 Français
- 🇧🇷 Português

El modo automático debe detectar el idioma de la pregunta. La respuesta debe mantenerse en el idioma utilizado.

**Ejemplo:**

> **Usuario:** How many cameras are active?
>
> **Chatbot:** There are currently 12 active cameras.

No traducir únicamente botones: el contenido conversacional también debe cambiar de idioma. Los reportes deben respetar el idioma seleccionado.

---

## 20. Declaración de la Persona Transhumana

Crear un módulo específico: **🌱 Persona Transhumana**

No presentar la declaración como un simple texto. Convertir los **12 principios** en una experiencia interactiva.

**El chatbot debe poder:**

- Explicar cada principio.
- Mostrar el principio del día.
- Realizar preguntas de reflexión.
- Proponer retos.
- Registrar retos.
- Mostrar progreso.
- Relacionar respuestas con principios.
- Mostrar los principios completados/explorados.

---

## 21. Principio del día

**Ejemplo:**

```text
🌱 PRINCIPIO DEL DÍA

#6
VOY MÁS ALLÁ DE MÍ

"Cada día mejoro, reinvento
y evoluciono..."

¿Quieres reflexionar sobre
este principio?

[REFLEXIONAR]
```

---

## 22. Reflexión

**Ejemplo de pregunta:**

> ¿Qué aspecto de tu vida consideras que puedes mejorar actualmente?

El usuario responde. El chatbot debe generar una respuesta reflexiva **basada exclusivamente en el contenido de la Declaración**, evitando presentarse como profesional médico o psicológico.

---

## 23. Retos

Cada principio puede tener retos.

**Ejemplo:**

```text
🎯 RETO

Principio #7
ME PERFECCIONO

Dedica 30 minutos hoy a aprender
algo nuevo relacionado con tu
formación profesional.

[ACEPTAR RETO]
```

**Estados:**

- Pendiente
- En progreso
- Completado

---

## 24. Mi evolución

Crear una pantalla:

```text
╔══════════════════════════════╗
║       🧬 MI EVOLUCIÓN        ║
╠══════════════════════════════╣
║                              ║
║ Principios explorados        ║
║ █████████░░  9 / 12          ║
║                              ║
║ Retos completados            ║
║ 17                           ║
║                              ║
║ Reflexiones                  ║
║ 24                           ║
║                              ║
║ Último principio             ║
║ #7 Me perfecciono            ║
╚══════════════════════════════╝
```

---

## 25. Modos del chat

El usuario debe poder seleccionar:

```text
┌───────────────────────────────┐
│ ¿Qué deseas hacer?            │
│                               │
│ 🖥️ Asistente S.V.I.          │
│ 📊 Análisis y reportes        │
│ 🌱 Persona Transhumana        │
│ 🌎 Idioma                     │
└───────────────────────────────┘
```

El sistema puede detectar automáticamente el contexto, pero los modos sirven para mejorar la experiencia.

---

## 26. Base de conocimiento

Crear:

```text
storage/app/knowledge/
│
├── svi_knowledge.json
├── transhuman_knowledge.json
├── languages.json
└── report_templates.json
```

La base S.V.I. debe mantener la información existente.

La documentación actual ya establece que la base de conocimiento debe ser **autocontenida**, **no contener credenciales** y actuar como **fuente de verdad**.

---

## 27. Base transhumana

Crear una estructura similar:

```json
{
  "principles": [
    {
      "id": 1,
      "title": "ORGANIZO",
      "description": "...",
      "reflection_questions": [],
      "challenges": []
    }
  ]
}
```

Incluir los **12 principios** proporcionados por el proyecto. **No modificar el significado original** de los principios.

---

## 28. RAG y contexto

Mantener el mecanismo de recuperación existente:

```text
Pregunta
   ↓
Normalización
   ↓
Detección de intención
   ↓
Identificación del módulo
   ↓
Recuperación de conocimiento
   ↓
Consulta MySQL si corresponde
   ↓
Gemini
   ↓
Respuesta
```

El diseño actual ya contempla recuperación por palabras clave, filtrado por rol y selección de entradas relevantes.

---

## 29. Seguridad

**Mantener:**

- API Key únicamente en Laravel.
- Sanctum.
- Rate limiting.
- Control por rol.
- Validación de mensajes.
- Protección contra prompt injection.
- No revelar prompts.
- No revelar API keys.
- No revelar información de otros usuarios.
- Logs sin contenido sensible.

> La API Key **nunca** debe llegar al APK/cliente en producción.

---

## 30. Estructura de archivos

Agregar o adaptar:

```text
vigilancia_app/
│
├── assets/
│   ├── knowledge/
│   │   ├── svi_knowledge.json
│   │   ├── transhuman_knowledge.json
│   │   └── languages.json
│   │
│   └── chatbot/
│       └── avatar/
│           ├── avatar_normal
│           ├── avatar_thinking
│           ├── avatar_speaking
│           └── avatar_error
│
└── lib/
    ├── models/
    │   ├── chat_message.dart
    │   ├── chatbot_mode.dart
    │   ├── transhuman_principle.dart
    │   └── challenge.dart
    │
    ├── services/
    │   ├── chatbot_service.dart
    │   ├── report_service.dart
    │   └── transhuman_service.dart
    │
    ├── screens/
    │   ├── chatbot_screen.dart
    │   ├── transhuman_screen.dart
    │   └── chatbot_settings_screen.dart
    │
    └── widgets/
        ├── chatbot_fab.dart
        ├── chatbot_avatar.dart
        ├── chat_bubble.dart
        ├── chat_input_bar.dart
        ├── typing_indicator.dart
        ├── quick_actions.dart
        ├── language_selector.dart
        └── font_size_selector.dart
```

> No crear archivos duplicados si ya existen componentes equivalentes.

---

## 31. Backend

En Laravel:

```text
app/
├── Http/
│   └── Controllers/
│       ├── ChatbotController.php
│       ├── ReportController.php
│       └── TranshumanController.php
│
└── Services/
    ├── GeminiService.php
    ├── ChatbotService.php
    ├── ReportService.php
    └── TranshumanService.php
```

**Rutas:**

| Método | Ruta |
|---|---|
| `POST` | `/api/chatbot` |
| `POST` | `/api/chatbot/report` |
| `GET` | `/api/chatbot/transhuman` |
| `GET` | `/api/chatbot/statistics` |

Las rutas exactas deben adaptarse a la estructura existente.

---

## 32. Base de datos

Antes de crear tablas nuevas, **revisar las tablas existentes**. No duplicar información.

Si no existen estructuras para las funciones nuevas, evaluar:

- `chatbot_challenges`
- `chatbot_reflections`
- `chatbot_preferences`
- `chatbot_reports`

Las preferencias podrían guardar:

- Idioma.
- Tamaño de letra.
- Preferencia claro/oscuro.
- Modo de chatbot.

---

## 33. Responsive

La interfaz debe funcionar correctamente en:

- Android.
- Windows.
- Web.

| Plataforma | Comportamiento |
|---|---|
| Móvil | Pantalla completa |
| Escritorio | Panel lateral / ventana de chat |

El diseño debe adaptarse al tamaño disponible.

---

## 34. Accesibilidad

**Implementar:**

- Tamaño de letra configurable.
- Buen contraste.
- Botones táctiles adecuados.
- Etiquetas semánticas.
- Compatibilidad con escalado del sistema.
- Lectura clara.
- No depender exclusivamente del color para indicar estados.

---

## 35. Animaciones

Mantener animaciones **discretas y profesionales**.

| Estado del avatar | Animación |
|---|---|
| Normal | Respiración/iluminación suave. |
| Pensando | Lente animado. |
| Respondiendo | Movimiento ligero. |
| Error | Indicador visual de error. |

No utilizar animaciones excesivas. El objetivo es que parezca un asistente tecnológico profesional, **no un juguete**.

---

## 36. Pruebas

Crear pruebas para:

### Chat
- Enviar mensaje.
- Recibir respuesta.
- Historial.
- Error.
- Sin conexión.

### Cámaras
- Consulta de cámaras.
- Estado.
- Desconexiones.

### Alertas
- Conteo.
- Prioridades.

### Eventos

### Reportes
- Diario.
- Semanal.
- Mensual.
- PDF.
- Excel.

### Idiomas
- Español.
- Inglés.
- Francés.
- Portugués.

### Transhumano
- 12 principios.
- Principio del día.
- Reflexión.
- Reto.
- Progreso.

### Interfaz
- Claro.
- Oscuro.
- Automático.
- Tamaño pequeño.
- Normal.
- Grande.
- Muy grande.
- Responsive.

---

## 37. Pruebas de seguridad

**Verificar que NO ocurra:**

- ❌ API Key visible en Flutter
- ❌ API Key en Git
- ❌ Usuario manipulando su rol
- ❌ Acceso a funciones de administrador
- ❌ Información de otros usuarios
- ❌ Prompt del sistema expuesto
- ❌ Consultas SQL generadas directamente por el usuario

**Debe existir:**

- ✅ Autenticación
- ✅ Autorización
- ✅ Validación
- ✅ Rate limit
- ✅ Logs seguros

---

## 38. Regla fundamental del chatbot

El chatbot **nunca debe inventar información del sistema**.

**Si no sabe:**

> "No tengo información suficiente para responder esa consulta dentro del S.V.I."

**Si el usuario pregunta algo fuera del alcance:**

> "Puedo ayudarte con el Sistema de Vigilancia y Monitoreo Integral, sus cámaras, alertas, eventos, reportes y con el módulo de Persona Transhumana."

---

## 39. Experiencia final esperada

La experiencia debe sentirse así:

```text
                🔵
          ┌─────────────┐
          │      ◉      │
          │   S.V.I.    │
          │   ASSISTANT │
          └─────────────┘

     Hola, soy el asistente S.V.I.

       ¿Qué necesitas?

 ┌─────────┐ ┌──────────┐
 │📹Cámaras│ │🚨Alertas │
 └─────────┘ └──────────┘

 ┌─────────┐ ┌──────────┐
 │📊Datos  │ │📄Reportes│
 └─────────┘ └──────────┘

 ┌─────────────────────┐
 │ 🌱 Persona          │
 │    Transhumana      │
 └─────────────────────┘

 ┌─────────────────────┐
 │ Escribe aquí...  ➤  │
 └─────────────────────┘
```

---

## 40. Orden de ejecución para Antigravity

> No intentar implementar todo simultáneamente. Ejecutar en este orden:

| Fase | Tarea |
|---|---|
| 1 | Analizar el proyecto existente. |
| 2 | Crear arquitectura del chatbot. |
| 3 | Crear interfaz gráfica. |
| 4 | Implementar avatar. |
| 5 | Implementar claro/oscuro. |
| 6 | Implementar tamaño de letra. |
| 7 | Implementar chat y conexión Flutter → Laravel. |
| 8 | Conectar Gemini. |
| 9 | Implementar base de conocimiento S.V.I. |
| 10 | Implementar consultas de cámaras. |
| 11 | Implementar alertas y eventos. |
| 12 | Implementar estadísticas. |
| 13 | Implementar reportes. |
| 14 | Implementar multilingüismo. |
| 15 | Implementar Persona Transhumana. |
| 16 | Implementar retos y evolución. |
| 17 | Implementar pruebas. |
| 18 | Optimización y despliegue. |

---

## 41. Criterio de terminado

El chatbot se considerará terminado cuando:

- [ ] Esté integrado en la aplicación existente.
- [ ] Tenga interfaz moderna.
- [ ] Utilice identidad visual S.V.I.
- [ ] Tenga avatar de cámara humanoide.
- [ ] Funcione en modo claro.
- [ ] Funcione en modo oscuro.
- [ ] Permita modo automático.
- [ ] Permita modificar tamaño de letra.
- [ ] Sea responsive.
- [ ] Permita consultar cámaras.
- [ ] Permita consultar alertas.
- [ ] Permita consultar eventos.
- [ ] Permita estadísticas.
- [ ] Permita análisis.
- [ ] Permita generar reportes.
- [ ] Permita PDF.
- [ ] Permita Excel.
- [ ] Soporte español.
- [ ] Soporte inglés.
- [ ] Soporte francés.
- [ ] Soporte portugués.
- [ ] Integre los 12 principios de la Declaración Transhumana.
- [ ] Tenga principio del día.
- [ ] Tenga reflexiones.
- [ ] Tenga retos.
- [ ] Tenga seguimiento de progreso.
- [ ] Respete los roles.
- [ ] Proteja la API Key.
- [ ] No invente datos.
- [ ] Rechace solicitudes fuera del alcance.
- [ ] Pase las pruebas de seguridad.
- [ ] Pase las pruebas de interfaz.
- [ ] Pase las pruebas funcionales.

---

## 🚨 Instrucción final para Antigravity

**Antes de escribir código, analiza completamente el proyecto existente y presenta un diagnóstico de su arquitectura actual.**

Identifica:

- Estructura Flutter.
- Sistema de navegación.
- Sistema de temas.
- Componentes reutilizables.
- API existente.
- Autenticación.
- Roles.
- Modelos.
- Tablas MySQL existentes.
- Módulos de cámaras.
- Módulos de alertas.
- Módulos de reportes.
- Sistema de configuración.

Después de analizarlo:

- No reemplaces componentes existentes sin justificación.
- Reutiliza la arquitectura existente y realiza modificaciones incrementales.
- Implementa el chatbot por fases y verifica que la aplicación continúe funcionando después de cada fase.
- No uses datos ficticios cuando exista información real en MySQL.
- No expongas la API Key de Gemini en Flutter.
- No inventes funciones que no existan en el sistema.
- El avatar debe representar una cámara humanoide inteligente y profesional.
- La interfaz debe transmitir vigilancia, seguridad, tecnología e inteligencia artificial mediante una estética azul tecnológica, especialmente en el modo oscuro.

El resultado final debe parecer un módulo desarrollado específicamente para S.V.I., **no un chatbot genérico añadido posteriormente**.

---

## 🎯 Recomendación importante antes de ejecutarlo

Como el plan actual ya contempla una arquitectura bastante concreta —incluyendo `ChatbotController`, `GeminiService`, `chatbot_screen.dart`, `chat_message.dart`, el JSON de conocimiento y el endpoint `/api/chatbot`—, conviene que Antigravity **primero inspeccione lo que ya existe** y no vuelva a crear esos archivos si ya fueron implementados.

Y hay una mejora especialmente importante: el chatbot debería **detectar primero la intención** de la pregunta:

```text
                 MENSAJE
                    │
                    ▼
            ¿Qué quiere hacer?
                    │
       ┌────────────┼────────────┐
       ▼            ▼            ▼
     S.V.I.      REPORTES    TRANSHUMANO
       │            │            │
       ▼            ▼            ▼
    MySQL        MySQL        JSON/DB
       │            │            │
       └────────────┼────────────┘
                    ▼
                  GEMINI
                    │
                    ▼
                RESPUESTA
```

Esto hará que el chatbot sea mucho más controlable y seguro que simplemente enviar cada pregunta directamente a Gemini. Además, encaja muy bien con la estrategia de recuperación y filtrado por roles que ya plantearon en el plan original.
